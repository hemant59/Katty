import React, { useState } from "react";
import UserPool from '../UserPool';
import { CognitoUserAttribute } from "amazon-cognito-identity-js";

export default function Signup(){
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  
  const onSubmit = event => {
    event.preventDefault();
    const attributes = [
      new CognitoUserAttribute({ Name:'phone_number', Value: phone})
    ];
    UserPool.signUp(email, password, attributes, null, (err, data) => {
      if(err) {
        console.error(err);
      } else {
        console.log(data);
        sendEmail();
      }
    })
  }
  
  const sendEmail = () => {
    let messageBody = `<!DOCTYPE html>
    <html>
    <head>
    <style>
    table {
      font-family: arial, sans-serif;
      border-collapse: collapse;
      width: 100%;
    }
    
    td, th {
      border: 1px solid #dddddd;
      text-align: left;
      padding: 8px;
    }
    
    tr:nth-child(even) {
      background-color: #dddddd;
    }
    </style>
    </head>
    <body>
    
    <h2>Customer Details</h2>
    
    <table>
      <tr>
        <th>Customer Name</th>
        <th>Email</th>
        <th>Broker Code</th>
        <th>Mailing Zipcode</th>
        <th>Action</th>
      </tr>
      <tr>
        <td>Lisa</td>
        <td>Lisa@gmail.com</td>
        <td>AA1112</td>
        <td>XYZ123</td>
      <td>
        <div>
          <button>Approve</button>
          <button>Reject</button>
        </div>
      </td>
      </tr>
    </table>
    
    </body>
    </html>`;
    const data = JSON.stringify({
      senderName:"debashisnath1992@gmail.com",
      senderEmail: "debashisnath1992@gmail.com",
      message: messageBody,
      subject: "Thanks for signing up",
    });
    fetch("https://q3arnrdj49.execute-api.us-east-1.amazonaws.com/sendEmail", {
      mode: "no-cors",
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: data
    })
    .then(data => {
      console.log(data);
    })
    .catch(error => {
      console.log(error);
    })
  }
  
  return(
    <div>
      <form onSubmit={onSubmit}>
        <input 
          value={email}
          type="email"
          placeholder="email"
          onChange={event => setEmail(event.target.value)}
        />
        <input 
          value={password}
          type="password"
          placeholder="password"
          onChange={event => setPassword(event.target.value)}
        />
        <input 
          value={phone}
          type="phone"
          placeholder="phone"
          onChange={event => setPhone(event.target.value)}
        />
        <button type="submit">Signup</button>
      </form>
    </div>
  )
}