import React, { Component } from 'react';
import { Table, Button } from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';
import Pool from "../UserPool";
import AWS from 'aws-sdk';

var FontAwesome = require('react-fontawesome');


export default class pdfFiles extends Component {
    state = {
        userBasedPDF: null
    }

    componentDidMount(){
        this.getUserDetails();
    }
    
    async getUserDetails(){
        await new Promise((resolve, reject) => {
            const user = Pool.getCurrentUser();
            if (user) {
              user.getSession(async (err, session) => {
                if (err) {
                  reject();
                } else {
                  const attributes = await new Promise((resolve, reject) => {
                    user.getUserAttributes((err, attributes) => {
                      if (err) {
                        reject(err);
                      } else {
                        const results = {};
                        
                        for (let attribute of attributes) {
                          const { Name, Value } = attribute;
                          results[Name] = Value;
                        }
                        console.log({results});
                        this.getListofFiles(results.phone_number);
                        resolve(results);
                      }
                    });
                  });
      
                  resolve({
                    user,
                    ...session,
                    ...attributes
                  });
                }
              });
            } else {
              reject();
            }
          });
    }
    getListofFiles(folderName){
        AWS.config.update({accessKeyId: 'AKIAYDQDVZ4RE5KREY5V', secretAccessKey: '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', region: 'us-east-1'});
        var s3 = new AWS.S3();
        var folder = folderName.substring(1);
        var params = { 
            Bucket: 'debascognito',
            Delimiter: '',
            Prefix: folder
        }
        s3.listObjects(params, function (err, data) {
        if(err)throw err;
            let array = [];
            console.log(data);
            if(data.Contents.length > 0){
                data.Contents.forEach((pdf) => {
                    if(pdf.Size > 0){
                        const keyData = {
                            Key: pdf.Key,
                            Bucket: 'debascognito'
                        }
                        s3.getSignedUrl('getObject', keyData, function (err, url) {
                            if (err) {
                                console.error(err)
                            } else {
                                let fileName = pdf.Key.split('/');
                                let exactFileName = fileName[fileName.length - 1];
                                array.push({path: url, name: exactFileName});
                                localStorage.setItem('files', JSON.stringify(array));
                            }
                        })
                    }
                });
            }
        });
        this.getFiles();
    }   

    async getFiles(){
        let files = await localStorage.getItem('files');
        let parseFiles = JSON.parse(files);
        this.setState({
            userBasedPDF: parseFiles
        },() => {
            localStorage.removeItem('files')
        })
    }

    download = (pdfFile) => {
        console.log("Force Download PDF");
        window.open(pdfFile, "_blank");

    }
    
    delete = () => {
        console.log("Delete PDF");
    }

    render() {
        const {userBasedPDF} = this.state;
        return (
            <div className='container table-responsive'>
            <h1>PDF Files</h1>
            <Table striped bordered hover>
                <thead>
                    <tr>
                    <th>Number</th>
                    <th>Document Name</th>
                    <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {
                        userBasedPDF && userBasedPDF.map((data, index) => {
                            return(
                                <tr key={index}>
                                    <td>{index}</td>
                                    <td>{data.name}</td>
                                    <td>
                                        <Button onClick={() => this.download(data.path)} variant="outline-secondary">
                                            <FontAwesome 
                                                className="super-crazy-colors"
                                                name="download"
                                            />
                                        </Button>
                                    </td>
                                </tr>
                            )
                        })
                    }
                </tbody>
                </Table>
            </div>
        )
    }
}